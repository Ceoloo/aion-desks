# Operator Desk (placeholder pack)

Draft-only Follow-Up plus Chief of Staff for owners.

This zip is a placeholder for the storefront. Replace with the real operating pack before launch.

- Never auto-send
- Human send only
- Not a second CRM
- Template 47 USD, template plus 45-min install 179 USD
