# Version — v1.1 (frozen)

Frozen 2026-09-02. Do not add a fifth price. Do not write monthly or subscription.

## SKUs (one-time only)

| SKU | Price | Zip |
| --- | --- | --- |
| Operator Desk template | $47 | `operator-desk.zip` (no INSTALL.md) |
| Operator Desk template + 45-min install | $179 | `operator-desk-install.zip` |
| Everyday Desk template | $39 | `everyday-desk.zip` (no INSTALL.md) |
| Everyday Desk template + install | $149 | `everyday-desk-install.zip` |

Radar is a door, not this pack and not a CRM. A Payment Link is checkout, not collected revenue.

## What "frozen" means

Pack files in this zip are the product. Edit your own charter after purchase. Do not expect a monthly drop, a retainer, or extra SKUs from this page.
