# Grok Bot import — Operator Desk

Stand up a **new** desk assistant from this pack. Do not export or clone a live company Chief of Staff, and do not copy Revenue, Content, or Markets rooms.

This is operating documents plus connector steps. It is not a black-box robot that sends mail.

## What to create

1. New Grok Bot (or equivalent assistant) named `Operator Desk`.
2. Description: paste the Mission, Authority, and hard stops from `CHARTER.md`. Keep **draft only**, **never gmail.send**, **never collect**, **never a second CRM**.
3. Put this folder in the workspace the assistant can read.
4. First instructions to the assistant: "You are Operator Desk. Follow CHARTER.md, then DENY.md, then ROUTING.md. Recommend. Do not send, spend, or collect."

## Connectors (narrow)

Follow `CONNECTORS.md`. Do this in the assistant's connector UI, not by pasting secrets into markdown.

| Connector | Allowed | Stop |
| --- | --- | --- |
| Calendar | Read; private unconfirmed holds | No guest invites, no domain-wide delegation |
| Gmail | Read + create/update **drafts** | Cancel if send appears on the consent screen |
| Notion | Parent page `Operator Desk` only: Pulse Log, Decision Pack Archive, Draft Pointers | No lead database, no pipeline board |

If a connector cannot be limited, skip it. Files + the operator's own apps still run the 30-minute setup.

## Routines

Create two weekday routines from `ROUTINES.md`:

- Morning pulse (operator's local morning). Quiet if empty.
- 4pm decision pack. Quiet if empty.

Do not create a send-later job. Do not create a collect job. Do not create a "sync CRM" job.

## Proof it worked

1. Test hold `HOLD (unconfirmed) — Operator Desk test` with no invitations. Delete it.
2. Test Gmail draft to the operator, subject `DESK TEST — do not send`. It must land in Drafts, not Sent. Delete it.
3. One pulse against **today**. If nothing matters, the assistant records `quiet` and stops.

## Hard no

- Importing this company's live CoS, Revenue, Content, or Markets.
- `gmail.send` or any send equivalent.
- Writing desk buyers into a CRM.
- Treating a Payment Link as collected revenue.
