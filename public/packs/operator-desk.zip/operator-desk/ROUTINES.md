# Routines — Operator Desk

Two weekday cadences. Weekends off unless the operator opts in for a single quiet check.

If Observe finds nothing: **stay quiet**. No "good morning" filler. No empty decision pack emailed to yourself for theater.

## Weekday morning pulse

**When:** After the operator's usual start, before deep work. Default 8:30–9:30 in the operator's local timezone.

**Goal:** A one-screen brief so the human knows conflicts, drafts waiting, and what can wait until 4pm.

### Steps

1. **Observe** calendar (today + next two business days) and Gmail (unread / starred / existing drafts).
2. **Reason** into at most five bullets. If you need more than five, you are writing a novel; cut to conflicts and decisions.
3. **Policy Check** the list. Strip anything that would require send/spend/collect without escalation.
4. **Act:** write the pulse to Notion `Pulse Log`. Create or refresh Gmail drafts **only** when the operator already owes a reply and the draft is clearly labeled draft.
5. **Record** `pulse` or `quiet`.

### Pulse template

```
Date:
Mode: pulse | quiet

Calendar:
- [conflict / hold / empty]

Inbox needing a human (max 5):
- [thread — why today — draft ready? yes/no]

Do not touch until 4pm:
- [items]

Escalations:
- send / spend / collect (human only)
```

### Quiet rule

If calendar is clear of conflicts and inbox has no thread that needs a human today: write `Mode: quiet` and stop. Do not invent follow-ups.

## 4pm human decision pack

**When:** Default 4:00pm local, weekdays. Shift if the operator's day ends earlier; never auto-send the pack to other people.

**Goal:** One pack the human can clear in 10–15 minutes: approve, edit, skip.

### Steps

1. **Observe** leftover pulse items, new mail, new holds, Notion open questions.
2. **Reason** into decisions, not updates. Each line is something a human can say yes/no to.
3. **Policy Check.** Anything that is send/spend/collect is listed as a decision, never as a completed act.
4. **Act:** write the pack to `Decision Pack Archive`. Attach draft pointers. Do not send the drafts.
5. **Record** outcomes the next morning (sent / skipped / edited) in one extra line. Still no CRM write.

### Decision pack template

```
Date:
Mode: pack | quiet

Decisions (yes / edit / skip):
1. [Send draft: subject — pointer]
2. [Confirm hold: time — or drop]
3. [Spend: what needs approval — desk will not pay]
4. [Collect: human-owned; desk will not chase]

Parked:
- [not today]

Quiet note:
- [if nothing to decide, delete the sections above and write quiet]
```

### Quiet rule (afternoon)

If there are no decisions: do not generate a pack body. Record `quiet` in the archive so the operator knows the desk ran and found nothing.

## What the desk does not do on a timer

- Send mail
- Chase invoices
- Add people to a pipeline
- Ping the operator twice if they already got a quiet record

## Optional Friday add-on

A three-bullet "week leftover" note in Notion, still draft-only, still quiet-if-empty. No weekly scoreboard of revenue collected.
