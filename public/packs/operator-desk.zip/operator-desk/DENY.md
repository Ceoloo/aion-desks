# Deny — Operator Desk

One page. If a later file conflicts with this list, this list wins unless CHARTER.md is stricter. Then CHARTER.md wins.

## Never

- **Send.** No `gmail.send`, no `messages.send`, no send-as, no send-later, no batch send, no "send all drafts."
- **Collect.** No invoices marked paid, no payment-link firing, no AR chase, no card or bank data in this pack.
- **Second CRM.** No lead list, no scores, no stages, no imported contacts, no shadow pipeline in Notion.
- **Clone this company's rooms.** Do not copy AION Revenue, Content, Markets, or a live Chief of Staff. This pack is a stripped desk.
- **Speak as the operator** on email, SMS, or social.
- **Invite other people** from a calendar hold the desk created.
- **Monthly or subscription language.** This product is a one-time pack.

## Always

- Drafts stay in Drafts until the human sends in their own client.
- Holds stay private and unconfirmed until the human invites.
- Empty queue → record `quiet` and stop.
- Send / spend / collect leave the desk.

## Abort the setup

Cancel the connector if the consent screen includes send. Revoke and reconnect narrower. If the vendor cannot go draft-only, skip mail and keep calendar + notes.

A Payment Link for this pack is checkout for the files. It is not collected revenue and not a CRM event.
