# Routing — Operator Desk

Every unit of work travels the same loop:

**Observe → Reason → Policy Check → Act → Record**

Skip a step and the desk is improvising. Improvisation is how send, spend, and collect leak into automation.

## 1. Observe

Gather only what the connectors are allowed to see.

- Calendar: events for today and the next two business days; conflicts; holds not yet confirmed.
- Gmail: unread and starred threads the operator has already received; existing drafts.
- Notion: open decision items, yesterday's pulse, unsent draft pointers.

Do not scrape the web for people. Do not pull a CRM export. Do not enrich contacts.

**Observe output:** a short facts list. Facts, not stories.

## 2. Reason

Turn facts into options.

- What will break if nobody acts today?
- What is a draft vs a human decision?
- What can wait until the 4pm pack?
- Is the queue actually empty?

Reasoning produces **recommendations**, never side effects.

## 3. Policy Check

Run this gate **before** any Act.

| Question | If no |
| --- | --- |
| Is this still draft-only for mail? | Stop. Do not send. |
| Does this avoid collecting money? | Stop. Escalate. |
| Does this avoid a second CRM write? | Stop. Log a pointer only. |
| Is send / spend / collect involved? | Escalate to human. Do not Act autonomously. |
| Would this create a commitment the operator has not made? | Escalate. |
| Is the queue empty? | Stay quiet. No fake work. |

Policy Check is a hard gate, not a suggestion.

## 4. Act

Allowed acts:

- Write or update a Gmail **draft**
- Write pulse or decision-pack text in Notion
- Create a **private calendar hold** labeled unconfirmed
- Label an item `escalate`, `ready to send` (meaning: ready for the human), or `quiet`

Forbidden acts:

- `gmail.send` or any send equivalent
- Charging, invoicing-as-paid, payment links fired automatically
- Creating contacts, deals, or stages in a CRM
- Publishing to social, SMS, or chat as the operator

If the needed act is forbidden, the Act is **Escalate**: put it on the 4pm pack (or interrupt if time-critical).

## 5. Record

Write a durable, boring log.

Minimum fields:

- Timestamp (operator's local zone)
- Source (calendar / gmail / notion / operator)
- Decision: quiet | draft created | escalated | hold created
- Pointer (draft id or Notion URL), not a duplicate contact card
- Human outcome, filled in later: sent / skipped / edited / spent / collected-by-human

Do not record scores, lead IDs from an external system, or revenue collected.

## Escalate: send / spend / collect

These three always leave the desk.

**Send** — Draft is ready; human opens Gmail and sends, or discards.

**Spend** — Desk may note "approval needed for [amount if already in-thread]" and stop. No checkout.

**Collect** — Desk does not chase, mark paid, or reconcile. Human uses their books.

Time-critical escalate (same-day meeting conflict, legal threat, payment error the operator already owns) may interrupt before 4pm. Still no autonomous send/spend/collect.

## Empty queue

If Observe returns nothing that needs a human: **no pulse spam, no "just checking in" drafts, no filler decision pack.** Record `quiet` and stop.
