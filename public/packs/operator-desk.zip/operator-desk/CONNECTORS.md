# Connectors — Operator Desk

Three connectors. Narrow scopes. Gmail is draft-only.

Revoke any permission that is broader than this page. If a vendor cannot satisfy the scope, skip that vendor and keep the desk on files + the operator's own apps.

## Calendar

**Purpose:** Observe the day; optionally place private unconfirmed holds.

**Use:** Google Calendar or equivalent, the same calendar the operator already lives on.

### Connection steps

1. In the calendar account, create a dedicated client or "app" labeled `Operator Desk` (or use the existing assistant integration if it supports per-app scopes).
2. Grant:
   - Read events on the primary calendar and any calendars the operator explicitly lists.
   - Create events **only** if you can mark them private / tentative / "hold — unconfirmed".
3. Do **not** grant:
   - Delete of other people's events
   - Send invitations on create
   - Domain-wide delegation
4. Test: create a 15-minute hold titled `HOLD (unconfirmed) — Operator Desk test`. Confirm no invitations went out. Delete the test hold.
5. Record the calendar id(s) in Notion under `Connectors — Calendar`. Do not paste refresh tokens into markdown in this folder.

### Operating rules

- Holds are local to the operator until the human confirms and sends the invite themselves.
- Never auto-accept inbound invites.
- Conflicts go to the pulse and the 4pm pack; the desk does not pick a winner.

## Gmail (draft-only)

**Purpose:** Read enough to draft; write drafts; never send.

**Hard stop:** no `gmail.send`, no `messages.send`, no "send as", no Gmail add-on that sends.

### Connection steps

1. Use a project/app named `Operator Desk Drafts`.
2. Request the narrowest scopes that still allow:
   - Read message metadata and bodies for threads you will draft into
   - Create and update **drafts**
3. Explicitly **exclude** send scopes. If the consent screen shows send, cancel and reconfigure.
4. If using a no-code glue tool, set the Gmail action to **Create Draft** only. Delete any Send Mail step. Disable "send after delay".
5. Test:
   - Create a draft to the operator's own address with subject `DESK TEST — do not send`.
   - Confirm it appears in Drafts, not Sent.
   - Confirm no copy left the mailbox.
   - Delete the test draft.
6. Log the connection in Notion: date, account address **you already use**, scopes granted. Do not store app secrets in this pack.

### Operating rules

- Drafts stay drafts. The human sends from Gmail.
- Do not auto-file mail into a parallel CRM.
- Do not add labels that mean "collected" or "closed-won".
- If a thread is about payment, draft only if the operator's 4pm pack asked for a reminder; still do not send.

## Notion

**Purpose:** Working notebook, pulse log, decision-pack archive, draft pointers. Not a CRM.

### Connection steps

1. Create a Notion workspace page `Operator Desk` (or a private page in the operator's existing workspace).
2. Create three child databases (or simple pages if you prefer files):
   - `Pulse Log`
   - `Decision Pack Archive`
   - `Draft Pointers` (link or Gmail draft id, thread subject, date — **no extra contact fields**)
3. Share the parent page with the integration. Do not share the whole workspace if you can avoid it.
4. Grant read/write on those pages only.
5. Test: insert one `quiet` pulse row and delete it.

### Operating rules

- Notion is not the pipeline. No stages, no scores, no imported lead tables.
- Pointers beat copies: store a link to the Gmail draft, not a cloned customer record.
- If you already have a CRM, leave it alone. This desk does not sync to it.

## Connector hygiene

- Rotate or revoke tokens if the desk is copied to a new machine.
- One operator identity per desk. Do not connect a shared inbox with send rights.
- Review scopes quarterly against this page.
