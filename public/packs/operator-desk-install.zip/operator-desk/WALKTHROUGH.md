# Walkthrough script — Operator Desk (12 minutes)

Record this later. Talk to camera or to a loom-style screen share. Do not load a real client inbox on screen if you cannot blur names. Use a dummy calendar and a test Gmail draft to yourself.

**Runtime target:** 12 minutes. If you overrun, cut stories, not the hard stops.

---

### 0:00–0:45 — Open

"This is Operator Desk. I bought a chief of staff plus a follow-up engine that is allowed to draft and not allowed to send. In the next twelve minutes I will show the charter, the routing loop, the three connectors, and the two weekday routines."

### 0:45–2:30 — What you bought

On screen: folder with the six markdown files.

"README is the 30-minute setup. Charter is law. Routing is Observe, Reason, Policy Check, Act, Record. Connectors are Calendar, Gmail draft-only, and Notion. Routines are morning pulse and 4pm decision pack. This walkthrough is the script I am reading now."

Pause. "Three hard stops: never gmail.send, never collect, never a second CRM."

### 2:30–4:30 — Charter

On screen: `CHARTER.md` headings.

"Two seats, one desk. Chief of staff prepares the day. Follow-up engine writes drafts. I am the sender. The desk may create private holds and Notion logs. It may not send mail, collect money, or clone my pipeline into Notion."

### 4:30–6:30 — Routing with a live example

Draw or show the five words.

"I observe today's calendar and a test unread thread. I reason: one conflict, one reply owed. Policy check: the reply is a draft, not a send; there is no spend and no collect. Act: I write a Gmail draft and a pulse line. Record: pulse, draft pointer, no contact card."

Show the test draft in **Drafts**, not Sent.

### 6:30–8:30 — Connectors

Click through Calendar permission screen (or a screenshot with secrets cropped).

"Calendar: read plus unconfirmed holds, no invites fired by the desk."

"Gmail: create draft only. If the consent screen shows send, I cancel."

"Notion: pulse log, decision pack archive, draft pointers. Not a CRM. No stages, no scores."

### 8:30–10:30 — Routines

Show empty vs full.

"Morning: five bullets or quiet. Afternoon: decisions the human can yes, edit, or skip. If the queue is empty, the desk stays quiet. That is a feature. I do not want a bot that congratulates me for having no mail."

### 10:30–12:00 — Close

"Setup is thirty minutes. Daily use is a pulse and a pack, or silence. I send, I spend, I collect. The desk drafts, routes, and records. If I catch it acting like a closer, I re-read the charter and cut the connector."

End screen: the three hard stops again.

---

## Recording notes

- Crop tokens, app passwords, and any real customer names.
- Do not demo a payment collection flow.
- If you slip and click Send, say so on camera, delete the lesson, and re-record the Gmail section.
- Optional B-roll: quiet pulse row in Notion.
