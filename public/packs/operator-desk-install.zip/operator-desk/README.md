# Operator Desk

A ready-to-run operating pack for a one-person company that still needs a chief of staff.

You bought a **draft-only** operating system: morning pulse, afternoon decision pack, calendar and inbox connectors, and a written charter so the desk never sends, never collects, and never becomes a second CRM.

This is not software you install as a black box. It is a set of operating documents plus connection steps. You keep the last mile: send, spend, collect.

## What you bought

| Asset | Purpose |
| --- | --- |
| `CHARTER.md` | Role, authority, and hard stops for Chief of Staff + Follow-Up Engine |
| `ROUTING.md` | Observe → Reason → Policy Check → Act → Record |
| `CONNECTORS.md` | Calendar, Gmail (draft only), Notion |
| `ROUTINES.md` | Weekday morning pulse and 4pm human decision pack |
| `DENY.md` | One-page never-send / never-collect / never-second-CRM |
| `GROK_BOT.md` | New assistant only. Do not clone a live company CoS |
| `INSTALL.md` | Only if you bought the 45-min install. A human sits it |
| `WALKTHROUGH.md` | 12-minute script you can record later |

If this zip has no `INSTALL.md`, you bought the template only. Run the 30-minute setup yourself.

**Not included:** a second CRM, live send from Gmail, collection workflows, scoring models, or any preloaded client list.

## 30-minute setup

Do this once. Do not skip the policy check.

### Minute 0–5 — Place the pack

1. Copy this folder into the workspace you actually use (Notion, local repo, or shared drive).
2. Read `CHARTER.md` end to end. If any line conflicts with how you want to operate, edit the charter **before** you connect anything.
3. Confirm the three hard stops: **never `gmail.send`**, **never collect**, **never second CRM**.

### Minute 5–15 — Connect read surfaces

1. Open `CONNECTORS.md`.
2. Connect **Calendar** in read + create-hold mode (holds stay private until you confirm).
3. Connect **Gmail** in **draft-only** mode. Verify the account cannot send from this desk.
4. Connect **Notion** as the working notebook (one database for drafts and logs; your existing CRM stays the system of record).

### Minute 15–22 — Route and log

1. Print or pin `ROUTING.md`.
2. Create two Notion pages (or local files): `Pulse Log` and `Decision Pack Archive`.
3. Confirm every Act that is a send, spend, or collect is labeled **Escalate to human**.

### Minute 22–30 — First dry run

1. Run the weekday morning pulse from `ROUTINES.md` against **today's calendar and inbox**, even if the day is light.
2. If there is nothing to surface, the desk stays quiet. That is correct.
3. At 4pm (or immediately if you are setting up after lunch), generate a human decision pack. Do not send anything from it.
4. Skim `WALKTHROUGH.md` so you can record the 12-minute walkthrough later.

## Daily use after setup

- Morning: pulse or silence.
- Afternoon: decision pack or silence.
- You send. You spend. You collect.
- The desk drafts, routes, and records.

## Support boundary

This pack is operating documentation. It does not replace legal, tax, or payment-processor advice. If a connector permission looks broader than draft/read, revoke it and reconnect with the narrower scope in `CONNECTORS.md`.
