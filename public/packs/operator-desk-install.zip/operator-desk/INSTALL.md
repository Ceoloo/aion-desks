# Install — Operator Desk (45 minutes)

This file ships only with the **template + 45-min install** SKU ($179, one-time). If you only bought the $47 template, you do not need this. Use README.md.

A human sits this with you. The desk does not run the session. Customer (or the operator's chosen human) owns the clock. No auto-email. No CRM write. A Payment Link is not collected revenue.

**Goal:** charter accepted, scopes draft-only, one real pulse, operator still hits send.

Use a dummy or blurred inbox. Do not load a client list onto the screen.

---

### 0–10 — Charter before connect

1. Open `CHARTER.md` and `DENY.md`. Read the three hard stops out loud: never `gmail.send`, never collect, never a second CRM.
2. Edit the charter **now** if a line conflicts with how this operator works. Do not connect first.
3. Confirm this is a stripped desk: no AION rooms, no live CoS clone (`GROK_BOT.md`).

Abort if they wanted auto-send or a pipeline in Notion. That is not this product. Do not invent a fifth price.

### 10–25 — Scopes

Follow `CONNECTORS.md` live.

1. Calendar: read + private holds. Test `HOLD (unconfirmed) — Operator Desk test`. Confirm **no invitations**. Delete it.
2. Gmail: app named `Operator Desk Drafts`. If the consent screen includes send, **cancel**. Reconfigure. Draft to self `DESK TEST — do not send`. Confirm Drafts, not Sent. Delete it.
3. Notion: parent `Operator Desk` with Pulse Log, Decision Pack Archive, Draft Pointers (link / draft id / subject / date only). No extra contact fields.

If Gmail cannot go draft-only, skip mail. Calendar + Notion still count as an install. Record the skip in Pulse Log.

### 25–40 — Dry run

1. Pin `ROUTING.md`.
2. Run today's morning pulse from `ROUTINES.md` against **this calendar and inbox**.
3. If nothing needs a human: record `quiet`. That is success.
4. If a reply is owed: create one Gmail draft. Do not send it.
5. Build a 4pm pack or a quiet record. Send / spend / collect lines are decisions, not acts.

### 40–45 — Human last mile

1. Operator opens the test or real draft in their own Gmail.
2. They send it to themselves, or they delete it. The desk never does.
3. Skim `WALKTHROUGH.md` so they can record later.
4. Book nothing automatically. If a follow-up sitting is needed, the human writes the time.

### After this hour (first 14 days)

Human-owned, not a bot loop: send still never fired from the desk; Notion did not grow stages or a lead table; empty days stayed quiet.

This purchase is not QUALIFIED, not WON, and not collect.
