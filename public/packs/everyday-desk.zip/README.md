# Everyday Desk (placeholder pack)

Calendar, inbox drafts, and a weekly brief for consumers.

This zip is a placeholder for the storefront. Replace with the real operating pack before launch.

- No CRM
- Drafts you send yourself
- Template 39 USD, template plus install 149 USD
