# Everyday Desk

A calmer operating pack for personal life and solo work that is not a sales team.

You bought a **never-send** desk: calendar awareness, inbox drafts, and a weekly brief. No CRM. No pipeline. No collection engine. No closer.

This is documentation you run with tools you already have. You keep send, spend, and any money conversations entirely in your own hands.

## What you bought

| Asset | Purpose |
| --- | --- |
| `CHARTER.md` | What the desk is allowed to do (draft, brief, stay quiet) |
| `ROUTING.md` | Observe → Reason → Policy Check → Act → Record |
| `CONNECTORS.md` | Calendar, Gmail drafts, Notion (or notes) |
| `ROUTINES.md` | Weekday morning pulse; 4pm human decision pack; weekly brief |
| `WALKTHROUGH.md` | 12-minute script you can record later |

**Not included:** CRM, pipeline, lead lists, scoring, send automation, or any business-development playbook.

## 30-minute setup

### Minute 0–5 — Place the pack

1. Copy this folder next to your notes.
2. Read `CHARTER.md`. Everyday Desk is a personal chief of staff, not a mail cannon.
3. Confirm: **never send**, **no CRM**, **no pipeline**.

### Minute 5–15 — Connect

1. Follow `CONNECTORS.md`.
2. Calendar: read your personal calendar; optional private holds that do not invite anyone.
3. Gmail: **draft only**. If a permission says send, refuse it.
4. Notion or a local notes folder: pulse log, weekly brief, draft pointers.

### Minute 15–22 — Route

1. Pin `ROUTING.md`.
2. Create `Pulse Log`, `Decision Pack Archive`, and `Weekly Briefs`.
3. Mark send/spend/collect as human-only.

### Minute 22–30 — Dry run

1. Run a morning pulse on **today**. If nothing matters, stay quiet.
2. Write a tiny 4pm pack or a quiet record.
3. Skim `WALKTHROUGH.md` for a later recording.

## Daily use

- Morning pulse or silence.
- Afternoon pack or silence.
- Once a week, a brief — or silence.
- You hit send. The desk never does.

## Boundary

This pack is not legal, medical, or financial advice. It will not manage other people's inboxes. Keep it on accounts you own.
