# Walkthrough script — Everyday Desk (12 minutes)

Record when you want. Use a dummy calendar and a draft to yourself so real names never hit the recording.

**Target:** 12 minutes.

---

### 0:00–0:40 — Open

"This is Everyday Desk. Calendar, inbox drafts, weekly brief. It never sends. There is no CRM and no pipeline. Twelve minutes, then you can copy the setup."

### 0:40–2:15 — Folder

Show the files.

"README is a 30-minute setup. Charter says never send. Routing is Observe, Reason, Policy Check, Act, Record. Connectors are calendar, Gmail drafts, and notes. Routines are morning pulse, 4pm pack, weekly brief. Quiet is allowed."

### 2:15–4:00 — Charter

"Personal chief of staff. It can draft. I send. It cannot collect money, store a list of people to nurture, or fire calendar invites."

### 4:00–6:15 — Routing demo

"I observe a calendar collision and one email I already owe. I reason those are the only two items. Policy check: both are drafts or holds, not sends. Act: I write a draft to myself in Gmail and a pulse line. Record: quiet is also a valid record if this had been empty."

Show Drafts, not Sent.

### 6:15–8:15 — Connectors

"Calendar read, private holds, no guests notified."

"Gmail: if I see send on the permission screen, I cancel."

"Notes: pulse, pack, weekly brief, pointers. If this starts looking like a CRM, I delete the extra properties."

### 8:15–10:30 — Routines

"Morning: short or silent. Afternoon: decisions I can finish in ten minutes. Weekly: a brief of my week, not a hunt list. Empty queues stay quiet on purpose."

### 10:30–12:00 — Close

"Thirty minutes to set up. Never send. No CRM. No pipeline. I will record this again if I ever click send by mistake — that click is the bug."

End card: **Never send. No CRM. Quiet is success.**

---

## Recording notes

- Blur or avoid real contacts.
- Do not demo payments.
- Crop tokens.
- Optional shot: a single `quiet` pulse row.
