# Routing — Everyday Desk

**Observe → Reason → Policy Check → Act → Record**

Same loop every time. Consumer desk, so the forbidden list is even simpler: no CRM, no pipeline, never send.

## 1. Observe

- Calendar: today and the next few days.
- Inbox: unread / starred / drafts that already exist.
- Notes: last pulse, open questions you wrote.

Do not scrape social graphs. Do not import address books into a new database.

**Output:** a fact list.

## 2. Reason

- What actually needs you today?
- What is only a draft?
- What belongs in the weekly brief instead?
- Is the answer "nothing"?

## 3. Policy Check

| Question | If no |
| --- | --- |
| Will this avoid sending? | Stop. |
| Is this free of CRM / pipeline structure? | Stop. Use a pointer or drop it. |
| Is send / spend / collect involved? | Escalate to you. No autonomous act. |
| Would this nag someone who did not ask? | Do not even draft. |
| Empty queue? | Stay quiet. |

## 4. Act

Allowed:

- Gmail **draft**
- Pulse, decision pack, or weekly brief in notes
- Private hold on your calendar
- Label: `quiet` | `draft` | `escalate`

Forbidden:

- Any send
- Any CRM or pipeline write
- Any collection
- Invites to other people

## 5. Record

Log time, source, decision, pointer. No scores. No imported IDs. Next day, you may add "I sent it" or "I dropped it."

## Escalate: send / spend / collect

**Send** — You open the draft.  
**Spend** — Desk notes "you need to decide," does not pay.  
**Collect** — Out of scope. Not this product.

Interrupt the day only for a same-day calendar collision or a message you already flagged as urgent. Still never send.

## Stay quiet if empty

No pulse essay. No weekly brief of filler. Record `quiet` and close.
