# Routines — Everyday Desk

Weekday morning pulse. 4pm human decision pack. Weekly brief. **Stay quiet if empty.**

No pipeline review. No CRM standup. No send-later queue.

## Weekday morning pulse

**When:** After you usually wake up and before the first deep block. Example: 8:30 local.

### Steps

1. Observe calendar and inbox.
2. Reason down to a handful of bullets.
3. Policy check: never send; no CRM shape.
4. Act: write the pulse; add drafts only for replies you already owe.
5. Record `pulse` or `quiet`.

### Template

```
Date:
Mode: pulse | quiet

Calendar:
- [collision / hold / empty]

Inbox (only if a human should see it today):
- [thread — draft ready? yes/no]

Later:
- [parked]

Escalate:
- send / spend / collect stay with me
```

**Quiet:** nothing needs you → `Mode: quiet` → stop.

## 4pm human decision pack

**When:** Default 4:00pm local weekdays.

This is your list, not a message to anyone else.

### Steps

1. Observe leftovers and new mail.
2. Reason into yes / edit / skip items.
3. Policy check.
4. Write the pack. Do not send drafts.
5. Tomorrow, optionally mark what you did.

### Template

```
Date:
Mode: pack | quiet

Decisions:
1. [Send this draft myself? pointer]
2. [Keep or drop hold]
3. [Spend: I decide]
4. [Anything money-related: I handle; desk does not collect]

Parked for the weekly brief:
- [...]
```

**Quiet:** no decisions → record `quiet` → no fake pack.

## Weekly brief

**When:** Sunday evening or Monday morning. Once.

**What it is:** a look back at your calendar and notes — what happened, what you still meant to draft, what to ignore.

**What it is not:** a scoreboard, a pipeline forecast, a collected-revenue report, a list of people to hunt.

### Template

```
Week of:
Mode: brief | quiet

From the calendar:
- [events that mattered]

Drafts still sitting (I will send or delete):
- [pointers]

Leave alone:
- [...]
```

If the week was empty of desk-worthy items: `quiet`.

## Timers that must not exist

- Auto-send
- Auto-nudge other humans
- Auto-advance a pipeline (there is no pipeline)
