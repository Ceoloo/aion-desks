# Deny — Everyday Desk

One page. CHARTER.md still wins if it is stricter.

## Never

- **Send.** No email send, SMS, chat, social, calendar invites fired by the desk, send-later, or batch send.
- **CRM.** No contact database, pipeline, stages, scores, lead IDs, or "people to nurture."
- **Collect.** No billing, no chasing anyone for money, no stored payment methods.
- **Clone a company OS.** Do not import someone else's sales rooms, revenue ledger, or live Chief of Staff. This is a personal desk.
- **Monthly or subscription language.** This product is a one-time pack.
- **Nag people who did not write to you.** Do not even draft a cold outreach list.

## Always

- Drafts sit in Drafts until you send or delete them in your own mail app.
- Holds are for you. You invite guests yourself, or you don't.
- Empty day → `quiet`. Do not invent chores.
- Send / spend / collect stay with you.

## Abort the setup

If a permission screen includes send, cancel. If a notes tool starts looking like a pipeline, delete the extra properties. Keep Pulse Log, Decision Pack Archive, Weekly Briefs, and draft pointers (subject + date + link only).

Buying this pack is not a sales win and not collected revenue.
