# Install — Everyday Desk (45 minutes)

This file ships only with the **template + install** SKU ($149, one-time). The $39 template uses README.md only.

A human sits this with you. Everyday Desk still never sends. No CRM. No pipeline. No auto-email. Payment Link is checkout, not collected revenue.

Keep other people's names off the screen if you can.

---

### 0–10 — Charter before connect

1. Read `CHARTER.md` and `DENY.md`. Everyday Desk is a personal chief of staff, not a mail cannon and not a company OS.
2. Confirm: never send, no CRM, no pipeline, no list of people to hunt.
3. Edit the charter if needed **before** connecting.

Abort if they wanted a follow-up engine for sales. That is Operator Desk, a different one-time SKU, not a monthly upgrade.

### 10–25 — Scopes

Follow `CONNECTORS.md`.

1. Calendar they already use. Test hold `HOLD (unconfirmed) — Everyday Desk test`. Nobody invited. Delete it.
2. Gmail: `Everyday Desk Drafts`. Cancel if send is on the screen. Draft to self `DESK TEST — do not send`. Drafts, not Sent. Delete it.
3. Notion page `Everyday Desk` or a notes folder: Pulse Log, Decision Pack Archive, Weekly Briefs, optional draft pointers. No contact properties.

Notes-on-disk is a complete install if they skip Notion.

### 25–40 — Dry run

1. Pin `ROUTING.md`.
2. Pulse **today**. Quiet if empty.
3. Draft only a reply they already owe. Do not draft cold notes to friends or clients who did not write.
4. 4pm pack or quiet. Mention the weekly brief; do not fill it with fake chores.

### 40–45 — Human last mile

1. They send or delete the test draft in their own mail app.
2. Skim `WALKTHROUGH.md` for a later recording.
3. No automatic calendar invite for a next session.

### After this hour (first 14 days)

Check that the desk still has no send path, no people database, and quiet days stay quiet.

Not QUALIFIED. Not WON. Not collect.
