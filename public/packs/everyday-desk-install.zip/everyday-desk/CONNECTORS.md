# Connectors — Everyday Desk

Calendar. Gmail drafts. Notion (or a notes folder). That is the whole map.

Gmail is draft-only. The desk never sends.

## Calendar

**Purpose:** See your week; optional private holds.

### Steps

1. Connect the calendar you already use (personal is fine).
2. Grant read. Grant create only if new events can stay private and **not** notify guests.
3. Refuse: send invitations, delete other people's events, full account takeover.
4. Test a 15-minute hold titled `HOLD (unconfirmed) — Everyday Desk test`. Confirm nobody was invited. Delete it.
5. Write the calendar name in your notes. Do not paste secrets into this folder.

### Rules

- Holds are for you until you invite people yourself.
- Do not auto-accept invites.
- Collisions go to the pulse; you pick.

## Gmail (never send)

**Purpose:** Draft replies. Stop there.

### Steps

1. Name the app `Everyday Desk Drafts`.
2. Scopes: read threads you need; create/update drafts.
3. **No send scope.** If the consent screen includes send, cancel.
4. In glue tools, the only Gmail action is Create Draft. Remove Send. Remove delay-send.
5. Test a draft to yourself: subject `DESK TEST — do not send`. Confirm Drafts, not Sent. Delete it.
6. Note the date and which address you connected. No tokens in markdown.

### Rules

- You send from the mail app, or not at all.
- Do not file mail into a people database.
- Do not auto-cc anyone.

## Notion (or notes)

**Purpose:** Pulse log, 4pm archive, weekly briefs, draft pointers.

Not a CRM. Not a pipeline.

### Steps

1. Page named `Everyday Desk`.
2. Children: `Pulse Log`, `Decision Pack Archive`, `Weekly Briefs`, optional `Draft Pointers` (subject + date + link only).
3. Share only that page with an integration, not the entire workspace.
4. Test a `quiet` row; delete it.

If you dislike Notion, the same four files on disk are enough.

### Rules

- No contact properties, stages, or scores.
- Pointers, not profiles.
- Do not sync a sales tool. There isn't one in this product.

## Hygiene

Revoke access if you stop using the desk. One person, one identity. Re-read scopes if a vendor updates permissions.
